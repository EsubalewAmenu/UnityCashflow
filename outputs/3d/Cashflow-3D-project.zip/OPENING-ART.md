Opening-screen artwork was generated with the built-in image generation tool and copied into the Unity project.

Saved assets:
- C:/Users/hp/Desktop/personal/UnityCashflow/Assets/Resources/Onboarding/professions.png
- C:/Users/hp/Desktop/personal/UnityCashflow/Assets/Resources/Onboarding/dreams.png

The existing city.png backdrop was reused. All card labels, amounts, selection states and navigation remain live Unity UI.

Final prompts:

1. Use case: stylized-concept. Asset type: Unity mobile board game portrait sprite atlas. Create an exact 5-column by 1-row grid of five separate equally sized portrait illustrations, entire canvas 5:1 if possible or widest supported. Five equal cells; each character centered in its own cell, consistent waist-up framing with full head and shoulders inside cell margins. Left to right: 1 friendly woman engineer with navy workshirt, yellow hard hat and rolled blueprint; 2 friendly Black woman teacher with curly hair, glasses and books; 3 older male medical doctor in white coat with stethoscope; 4 friendly male janitor in blue work overalls holding cleaning tool; 5 confident woman lawyer in plum business suit holding document folder. Premium casual mobile game illustration, charming expressive faces, polished hand-painted 3D-cartoon shading, warm lighting, cream background in every cell. No text, no numbers, no borders, no logos. These will be cropped into five character cards; keep subjects independent and do not cross cell edges.

2. Use case: stylized-concept. Asset type: Unity game dream-card illustration atlas. Exact 4 columns by 2 rows equal grid, landscape canvas. Each of 8 cells independently illustrates a lifelong dream, with no gaps, no border and no text. Row1 left to right: children learning financial skills in a bright classroom with a toy piggy bank; vivid underwater coral reef with tropical fish; luxury white superyacht on turquoise sea; African wildlife sanctuary with elephants and acacia trees. Row2 left to right: beautiful alpine chalet snowy mountain skiing; private tropical island palm trees and beach; travel adventure with the pyramids and hot air balloons; welcoming community health clinic with doctor and family. Polished colorful casual mobile game painted illustration, inviting sunlit lighting, coherent style, crisp rich details. Each scene fills exactly one rectangular quarter-width half-height cell; no scene crosses grid lines. No letters, numbers, UI, watermarks, or logos.
